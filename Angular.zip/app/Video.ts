
export class Video
{
    id:number;
    description:string;
    vidUrl:string;
}
