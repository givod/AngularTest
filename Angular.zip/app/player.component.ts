import { Component } from '@angular/core';


@Component({
  selector: 'player',
  template: `
           <video width="900px" height="450px" controls autoplay>
           <source src="{{source}}" type="video/mp4">
           Your browser does not support the video tag.
           </video> `,
           inputs :[`source`]
})
export class PlayerComponent 
 {
    name: string ;
    //source: string = '/app/videoRep/BastilleDay.mp4';
     public source: string = '';

     //http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm
  
 }