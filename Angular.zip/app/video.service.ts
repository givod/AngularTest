import {Video} from './Video'
import {VID} from './Videos'
import {Injectable} from '@angular/core'

@Injectable()
export class VideoService
{
    getVideos(): Video[]{

        return VID;
    }
}