"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Videos_1 = require('./Videos');
var video_service_1 = require('./video.service');
require('rxjs/add/operator/map');
require('rxjs/add/operator/toPromise');
var AppComponent = (function () {
    function AppComponent(_videos) {
        this._videos = _videos;
        this.name = 'Catalogue';
        this.player = 'Cinema';
        this.show = false;
        this.di = '12';
        this.di2 = '0';
        this.source = '';
        this.movieList = Videos_1.VID;
    }
    AppComponent.prototype.ngOnInit = function () {
        this.movieList = this._videos.getVideos();
    };
    AppComponent.prototype.showPlayer = function (vidUrl) {
        this.di = '4';
        this.di2 = '8';
        if (this.show) {
            this.url = vidUrl;
        }
        else {
            this.show = true;
            this.url = vidUrl;
        }
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            template: "\n  <div class=\"row\">\n  <div class=\"set\">\n      <div class=\"col-xs-{{di}} row-fluid \" style=\"padding-right:0px;\">\n      <div class=\"jumbotron show\">\n      <h1 style=\"font-size: 30px;\">\n      {{name}}\n      </h1>\n      </div>\n      <div>\n        <p *ngFor=\"let m of movieList\" class=\"movieItem  {{m.description.split('').join('')}}\" (click)=\"showPlayer(m.vidUrl)\">\n        <span class=\"movieName\">{{m.description}}</span>\n        </p>\n    </div>\n      </div>\n      </div>\n      <div class=\"col-xs-{{di2}} row-fluid\" style=\"padding-left:0px;\" *ngIf=\"show == true\">\n      <div class=\"jumbotron show\">\n      <h1 style=\"font-size: 30px;\">{{player}}</h1>\n      </div>\n      <player [source]=\"url\"></player>\n      </div>\n  </div>\n  \n  ",
            providers: [video_service_1.VideoService]
        }), 
        __metadata('design:paramtypes', [video_service_1.VideoService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map