"use strict";
exports.VID = [
    { id: 11, description: 'BatManVsSuperman', vidUrl: '/app/videoRep/BastilleDay.mp4' },
    { id: 12, description: 'NeedForSpeed', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 13, description: 'Inception', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 14, description: 'CivilWar', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 15, description: 'BatManVsSuperman', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 16, description: 'NeedForSpeed', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 17, description: 'Inception', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 18, description: 'CivilWar', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 11, description: 'BatManVsSuperman', vidUrl: '/app/videoRep/BastilleDay.mp4' },
    { id: 12, description: 'NeedForSpeed', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 13, description: 'Inception', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 14, description: 'CivilWar', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 15, description: 'BatManVsSuperman', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 16, description: 'NeedForSpeed', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 17, description: 'Inception', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' },
    { id: 18, description: 'CivilWar', vidUrl: 'http://www.html5rocks.com/en/tutorials/video/basics/devstories.webm' }
];
//# sourceMappingURL=Videos.js.map