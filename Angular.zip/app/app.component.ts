import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {PlayerComponent} from './Player.component'
import {Video} from './Video'
import {VID} from './Videos'
import {VideoService} from './video.service'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';


@Component({
  selector: 'my-app',
  template: `
  <div class="row">
  <div class="set">
      <div class="col-xs-{{di}} row-fluid " style="padding-right:0px;">
      <div class="jumbotron show">
      <h1 style="font-size: 30px;">
      {{name}}
      </h1>
      </div>
      <div>
        <p *ngFor="let m of movieList" class="movieItem  {{m.description.split('').join('')}}" (click)="showPlayer(m.vidUrl)">
        <span class="movieName">{{m.description}}</span>
        </p>
    </div>
      </div>
      </div>
      <div class="col-xs-{{di2}} row-fluid" style="padding-left:0px;" *ngIf="show == true">
      <div class="jumbotron show">
      <h1 style="font-size: 30px;">{{player}}</h1>
      </div>
      <player [source]="url"></player>
      </div>
  </div>
  
  `,
  providers:[VideoService]
})
export class AppComponent  implements OnInit
 {
   name: string = 'Catalogue'; 
    player:string = 'Cinema'
    show:boolean = false;
    di:string = '12'
    di2:string = '0' 
    source:string = '';
    url:string;
    public movieList: Array<Video>  = VID;

   constructor(private _videos:VideoService){}

   ngOnInit()
   {
     this.movieList = this._videos.getVideos();
   }

    
    showPlayer(vidUrl:any)
    {
      this.di = '4'
      this.di2 = '8'
      if (this.show)
      {
         this.url = vidUrl;   
      }
      else
      {
        this.show = true;
        this.url = vidUrl;
      }
    }
  
 }
